var bm25 = require('wink-bm25-text-search');
var nlp = require('wink-nlp-utils');
const csv = require('csv-parser');
const fs = require("fs");


const mongoose = require("mongoose");
// DataBase Connection
mongoose.connect('mongodb://karansawant:jeTX5ydaYRM3UwJE@covid-shard-00-00-1dr8b.mongodb.net:27017,covid-shard-00-01-1dr8b.mongodb.net:27017,covid-shard-00-02-1dr8b.mongodb.net:27017/dataManager?ssl=true&replicaSet=covid-shard-0&authSource=admin&retryWrites=true&w=majority', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(console.dir("Connecting to MongoDB - DataManager..."));

// Collection Objects
var dbraw = mongoose.model("raw", new mongoose.Schema({ strict: false }), "raw");
var dbpheremones = mongoose.model("pheremones", new mongoose.Schema({ strict: false }), "pheremones");

var shielded = {};
var metamorph = {};
dbraw.findOne({site: "equishell"}).then(meta=>{
    addShield(meta.get("data"));
});
dbpheremones.findOne({site: "equishell"}).then(meta=>{
    addPher(meta.get("data"));
});
let addPher = data =>{
    metamorph = data;
};
let addShield = data =>{
    shielded = data;
};
let compareTwoStrings = (first, second) => {
	first = first.replace(/\s+/g, '');
	second = second.replace(/\s+/g, '');
	if (!first.length && !second.length) return 1;                   // if both are empty strings
	if (!first.length || !second.length) return 0;                   // if only one is empty string
	if (first === second) return 1;       							 // identical
	if (first.length === 1 && second.length === 1) return 0;         // both are 1-letter strings
	if (first.length < 2 || second.length < 2) return 0;			 // if either is a 1-letter string
	let firstBigrams = new Map();
	for (let i = 0; i < first.length - 1; i++) {
		const bigram = first.substring(i, i + 2);
		const count = firstBigrams.has(bigram)? firstBigrams.get(bigram) + 1: 1;
		firstBigrams.set(bigram, count);
	};
	let intersectionSize = 0;
	for (let i = 0; i < second.length - 1; i++) {
		const bigram = second.substring(i, i + 2);
		const count = firstBigrams.has(bigram)? firstBigrams.get(bigram): 0;
		if (count > 0) {
			firstBigrams.set(bigram, count - 1);
			intersectionSize++;
		}
	}
	return (2.0 * intersectionSize) / (first.length + second.length - 2);
};
let areArgsValid = (mainString, targetStrings) => {
	if (typeof mainString !== 'string') return false;
	if (!Array.isArray(targetStrings)) return false;
	if (!targetStrings.length) return false;
	if (targetStrings.find(s => typeof s !== 'string')) return false;
	return true;
};
let findBestMatch = (mainString, targetStrings) => {
	if (!areArgsValid(mainString, targetStrings)) throw new Error('Bad arguments: First argument should be a string, second should be an array of strings');
	const ratings = [];
	let bestMatchIndex = 0;
	for (let i = 0; i < targetStrings.length; i++) {
		const currentTargetString = targetStrings[i];
		const currentRating = compareTwoStrings(mainString, currentTargetString);
		ratings.push({target: currentTargetString, rating: currentRating});
		if (currentRating > ratings[bestMatchIndex].rating) {
			bestMatchIndex = i;
		}
	}
	const bestMatch = ratings[bestMatchIndex];
	return bestMatch;
};
let nucletechSupport = token =>{
    let queries = Object.keys(metamorph.variation_mapper);
    queries = queries.map(function(x){ return x.toLowerCase() });
    let query = findBestMatch(token, queries); // To be replaced by BM25
    console.log(query)
    if(query.rating>=0.6){
        query = query.target;
    }else{
        query = token;
    }
    return query.match(/\S+/g);
};
let nucletechCore = tokens =>{
    let intent_pred = [];
    let zindex = [];
    tokens.forEach(token=>{
        let token_idx = tokens.indexOf(token);
        let vocab_idx = metamorph.vocab.indexOf(token);
        if(vocab_idx!==-1){
            if ((token_idx+1)!==tokens.length){
                let next_idx = metamorph.vocab.indexOf(tokens[token_idx+1]);
                let current_tensor = metamorph.tensor_word[vocab_idx];
                if((current_tensor[next_idx] || -1)>0){
                    let temp_pred = [...metamorph.tensor_word_intent[vocab_idx]];
                    zindex.forEach(z=>{
                        temp_pred[z] = 0;
                    });
                    zindex = [];
                    let i = -1;
                    while((i = temp_pred.indexOf(0, i+1))!==-1) zindex.push(i);
                    intent_pred.push(temp_pred);
                }else{
                    // Same Code Here
                    let intent_pre = intent_pred.reduce(function (r, a) {
                        a.forEach(function (b, i) {
                            r[i] = (r[i] || 0) + b;
                        });
                        return r;
                    }, []);
                    let intent = intent_pre.indexOf(Math.max(...intent_pre));
                    let answer = shielded.Answer[intent];
                    if(answer===undefined){
                        answer = "I'm not certain whether I can give an accurate reply or not.";
                        intent = "noanswer";
                    }
                    return {answer: answer, intent: intent};
                }
            }else if((token_idx+1)===tokens.length){
                let temp_pred = [...metamorph.tensor_word_intent[vocab_idx]];
                zindex.forEach(z=>{
                    temp_pred[z] = 0;
                });
                zindex = [];
                let i = -1;
                while((i = temp_pred.indexOf(0, i+1))!==-1) zindex.push(i);
                intent_pred.push(temp_pred);
            }
        }
    });
    let intent_pre = intent_pred.reduce(function (r, a) {
        a.forEach(function (b, i) {
            r[i] = (r[i] || 0) + b;
        });
        return r;
    }, []);
    let intent = intent_pre.indexOf(Math.max(...intent_pre));
    let answer = shielded.Answer[intent];
    if(answer===undefined){
        answer = "I'm not able to process your query at the moment";
        intent = "noanswer";
    }
    return {answer: answer, intent: intent};
};
let engine = (value) => {
    console.log(value);
    let result = nucletechSupport(value);
    result.forEach(r=>{
        console.log(r)
    })
    let intent = nucletechCore(result);
    return intent;
};
module.exports = {engine: engine, docs: shielded};