var equiModule = require("../engine/equishell");
var cousineModule = require("../engine/cosine");
var similarModule = require("../engine/stringSim");

let equiCore=question=>{
    let results = equiModule.engine(question);
    console.log(results);
    return results;
};

module.exports = equiCore;