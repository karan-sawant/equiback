const bodyParser = require("body-parser");
const CryptoJS = require("crypto-js");
const express = require("express");
var cors = require('cors');

// Custom Code Require
var equiCore = require("./engine/core");
var equishell = require("./engine/equishell")

const app = express();
const whitelist = ['www.equishell.com', "https://www.equishell.com"];
var corsOptionsDelegate = (req, callback) => {
    let corsOptions = {
        allowedMethods: ["POST"],
        allowedHeaders: ["Content-Type", "Authorization"],
    };
    if (whitelist.indexOf(req.header('Origin')) !== -1||whitelist.indexOf("*") !== -1) {
      corsOptions['origin'] = true // reflect (enable) the requested origin in the CORS response
    } else {
        corsOptions['origin'] = false // disable CORS for thi.s request
    }
    callback(null, corsOptions); // callback expects two parameters: error and options
}

app.use(cors(corsOptionsDelegate));

app.use(bodyParser.urlencoded({limit: '50mb', extended: true}));
// app.use(bodyParser.json({limit: '50mb', extended: true}));
app.use(express.json({limit: '50mb'}));

const server = app.listen(8090, "0.0.0.0");

// Socket IO Connection
const io = require("./socket").init(server);

io.on("connection", socket=>{
    console.log(socket.client.conn.server.clientsCount);
    socket.on("message", data=>{
        let start = new Date().getTime();
        let answer = equiCore(data.message.toLowerCase());
        let log = logRequest({data: data, answer: answer});
        let end = new Date().getTime();
        answerDisct = {answer: answer, time: (end-start)};
        answerHash = CryptoJS.RabbitLegacy.encrypt(JSON.stringify(answerDisct), "HobjShtfaLthqyFF35w1UwKhfz6IceeY6XpmF6a0fovNYmPBXE+QpWiFiGNOVwfoaWWmsknSGlPHywctskkKXQ==").toString();
        console.log(answerDisct)
        socket.emit("answers", answerHash);
    });
});

async function logRequest (data) {
    // save to mongodb
    return 200;
}